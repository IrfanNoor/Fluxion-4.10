<?php
	require_once("authenticator.php");

	switch ($candidate_code) {
		# case "1": echo ""; break;
		case "2": echo "authenticated"; break;
		# default: echo ""; break;
		default: break;
	}
