## Arguments table

| Arguments  | Describtion |
| ------------- | ------------- |
| -a | Give a Attack  |
| -e | Give a certain essid |
| -b | Give a certain bssid |
| -- | Maker is required | 
| -a | Access point interface |
| -j | Jamming interface |
| -x | Use xterm instead of tmux |
| -v | Print version number |
| -d | Run fluxion in debug mode |
| -k | Kill wireless connection if it is connected |
| -m | Run fluxion in manual mode instead of auto |
| -l | Language |

## Samples
`./fluxion -a [ATTACK] -e [ESSID] -b [BSSID] -c [CHANNEL] -- -a [AP INTERFACE] -j [JAMMING INTERFACE]`
